/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "67d572b748df85075160c99d517f1870"
  }, {
    "url": "pwa-512x512.png",
    "revision": "70fd04335bce97392947f679b6c380d6"
  }, {
    "url": "pwa-192x192.png",
    "revision": "55178919b1ac42aef8948060df77eb59"
  }, {
    "url": "index.html",
    "revision": "33814de680e21fb231840fd427c3f53d"
  }, {
    "url": "icon.svg",
    "revision": "a020567715e976ed19c779e2200c0e1d"
  }, {
    "url": "favicon.ico",
    "revision": "a1daaef3b7e570fbc7fef3dfb9a7786b"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "86eae05c47721883822d6cdb80c910ec"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/index-wVxVk6cP.css",
    "revision": null
  }, {
    "url": "assets/index-DxBNvalZ.js",
    "revision": null
  }, {
    "url": "assets/aistudio/screenshot_1_1ee9b470.png",
    "revision": null
  }, {
    "url": "assets/aistudio/222_23f76d5d.html",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "86eae05c47721883822d6cdb80c910ec"
  }, {
    "url": "favicon.ico",
    "revision": "a1daaef3b7e570fbc7fef3dfb9a7786b"
  }, {
    "url": "icon.svg",
    "revision": "a020567715e976ed19c779e2200c0e1d"
  }, {
    "url": "pwa-192x192.png",
    "revision": "55178919b1ac42aef8948060df77eb59"
  }, {
    "url": "pwa-512x512.png",
    "revision": "70fd04335bce97392947f679b6c380d6"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "67d572b748df85075160c99d517f1870"
  }, {
    "url": "manifest.webmanifest",
    "revision": "409edd9563003f0cd35fcf19f13d3271"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
